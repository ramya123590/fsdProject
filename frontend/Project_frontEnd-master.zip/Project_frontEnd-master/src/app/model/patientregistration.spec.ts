import { Patientregistration } from './patientregistration';

describe('Patientregistration', () => {
  it('should create an instance', () => {
    expect(new Patientregistration()).toBeTruthy();
  });
});
