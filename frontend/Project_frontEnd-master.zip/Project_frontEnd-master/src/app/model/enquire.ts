export class Enquiry {
    constructor( public userName : string, public  email: string, public branch: string, public message: string){}
}
