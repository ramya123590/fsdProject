export class Patientregistration {
     patient_id:Number;
	userId:String;
	 firstName:String ;

  middleName:String;

	  lastName:String;
	 email:String;
	gender:String;
	 dateofbirth: Date;
	
	Address:String ;
	
	  city:String;

	  state:String;

	  pincode:Number;

	  phone:Number;
	 password: String;


}
