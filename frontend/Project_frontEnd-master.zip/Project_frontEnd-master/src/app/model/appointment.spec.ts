import { Appointment } from './appointment';

describe('Appointment', () => {
  it('should create an instance', () => {
    expect(new Appointment()).toBeTruthy();
  });
});
