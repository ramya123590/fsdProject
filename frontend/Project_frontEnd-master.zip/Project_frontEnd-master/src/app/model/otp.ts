export class Otp {
    email:String;
    otp:String;
   otp1:String;

}
