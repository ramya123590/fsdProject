import { Otp } from './otp';

describe('Otp', () => {
  it('should create an instance', () => {
    expect(new Otp()).toBeTruthy();
  });
});
