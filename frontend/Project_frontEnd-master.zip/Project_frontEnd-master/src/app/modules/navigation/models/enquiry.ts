export class Enquiry {

    constructor( userName : string,  email: string,  branch: string,  message: string){}
}
