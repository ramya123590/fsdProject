export class Branch {
    constructor( public branchName:string){}
}
