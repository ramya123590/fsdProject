export class Enquiryreply {
    email:String
    message:String
}
