import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-type-pay',
  templateUrl: './type-pay.component.html',
  styleUrls: ['./type-pay.component.css']
})
export class TypePayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
