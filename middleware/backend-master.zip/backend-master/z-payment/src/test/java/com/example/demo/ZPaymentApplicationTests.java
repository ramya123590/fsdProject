package com.example.demo;



class ZPaymentApplicationTests {

	
	void contextLoads() {
	}

}
