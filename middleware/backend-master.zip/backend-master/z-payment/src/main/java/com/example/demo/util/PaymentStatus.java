package com.example.demo.util;

public enum PaymentStatus {

    Pending,Failed,Success
}