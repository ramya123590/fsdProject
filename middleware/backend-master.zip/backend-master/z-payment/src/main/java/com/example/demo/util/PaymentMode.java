package com.example.demo.util;
public enum PaymentMode {

    NB,DC,CC
}