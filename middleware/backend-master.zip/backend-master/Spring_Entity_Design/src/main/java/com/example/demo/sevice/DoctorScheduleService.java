package com.example.demo.sevice;

import java.util.List;
import java.util.Optional;

/*
 * import com.example.demo.entity.DoctorSchedule;
 * 
 * public interface DoctorScheduleService { public List<DoctorSchedule>
 * getDoctorSchedules();
 * 
 * public void saveDoctorSchedule(DoctorSchedule theDoctorSchedule);
 * 
 * public Optional<DoctorSchedule> getDoctorScheduleById(int theId);
 * 
 * public void deleteDoctorScheduleById(int theId);
 * 
 * }
 */
